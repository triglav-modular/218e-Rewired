#!/bin/bash
RES="$(cd "$(dirname "$0")" && pwd)"
BUNDLE="$(cd "$(dirname "$0")/../.." && pwd)"

# A quarantined app runs from a read-only copy of itself, and that copy is not
# where the person put anything.  The system will say where the original is, so
# the log and the record can go where they were always meant to: beside the app,
# in the folder that was unzipped.
case "$BUNDLE" in
    */AppTranslocation/*)
        REAL="$("$RES/support/resolve-translocation" "$BUNDLE" 2>/dev/null)"
        [ -n "$REAL" ] && BUNDLE="$REAL" ;;
esac
BESIDE="$(dirname "$BUNDLE")"

# Only if that folder can be written to.  Dragged into /Applications, or
# translocated with nothing willing to resolve it, it cannot be - and then
# there is nothing worth keeping anyway, so it goes somewhere temporary rather
# than into a folder of ours that would outlive the run.
if [ -w "$BESIDE" ]; then
    WORK="$BESIDE"
else
    WORK="${TMPDIR:-/tmp}"
fi

# Terminal opens a file; it cannot be handed an environment.  This shim carries
# it, and lives in the temporary directory because it is worth nothing after
# the run and the system clears it out on its own.
#
# printf %q, not a here-document.  These paths come from wherever the app was
# put, the shim is a shell script, and bash reads it: a folder named
# $(something) inside double quotes is a command, and it ran.  %q quotes them
# so they come back out as the strings they are.
RUNNER="${TMPDIR:-/tmp}/218e-rewired-run.command"
printf '#!/bin/bash\nexport REWIRED_WORKDIR=%q\nexec %q\n' \
       "$WORK" "$RES/Program218e_v3_Rewired_macOS.command" > "$RUNNER"
chmod +x "$RUNNER"
open -a Terminal "$RUNNER"
